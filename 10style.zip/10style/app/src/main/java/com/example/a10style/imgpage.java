package com.example.a10style;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class imgpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imgpage);
    }
}